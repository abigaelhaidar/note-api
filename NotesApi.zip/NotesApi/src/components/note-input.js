import { notesData as initialNotesData } from './notes.js'; 

let notesData = JSON.parse(localStorage.getItem('notesData')) || initialNotesData;
const notesListElement = document.querySelector('#notesList');

function createNoteItemElement({ id, title, body }) {
  return `
    <div class="note-item" data-noteid="${id}">
      <h3>${title}</h3>
      <p>${body}</p>
      <button class="delete-note" data-noteid="${id}">Hapus</button>
    </div>
  `;
}

function renderNotes() {
  const listOfNoteItem = notesData.map((note) => createNoteItemElement(note));
  notesListElement.innerHTML = listOfNoteItem.join('');
}

renderNotes();

const notesButton = document.querySelector('.notes-button');
const noteModal = document.getElementById('noteModal');
const closeModal = document.querySelector('.close');

// Event listener untuk menerima catatan baru dari custom element
document.querySelector('note-content').addEventListener('note-added', (event) => {
  const newNote = event.detail;
  notesData.push(newNote);
  renderNotes();
  localStorage.setItem('notesData', JSON.stringify(notesData));

  noteModal.style.display = 'none';
});

// Event listener untuk membuka modal
notesButton.addEventListener('click', function() {
  noteModal.style.display = 'block';
});

// Event listener untuk menutup modal
closeModal.addEventListener('click', function() {
  noteModal.style.display = 'none';
});

// Tutup modal saat area di luar modal diklik
window.addEventListener('click', function(event) {
  if (event.target === noteModal) {
    noteModal.style.display = 'none';
  }
});

document.querySelector('note-content').addEventListener('delete-note', (event) => {
  const noteIndex = event.detail.index;
  notesData.splice(noteIndex, 1); // Hapus catatan berdasarkan index
  renderNotes();
});
